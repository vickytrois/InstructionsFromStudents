/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Students;
/**
 *
 * @author v3gc
 */
public class StudentsController {

    private Students student;
      
    public double calculateAverage () {
        student.setGradeAverage((student.getStudentsGrade1() + student.getStudentsGrade2() + student.getStudentsGrade3())/3);
    }
    
    public void showConcept(){
        if (calculateAverage() >=0 && calculateAverage()<=4.9){
            System.out.println("The student's average is " + calculateAverage() + " and their concept is D ");
        }
        else if (calculateAverage() >=5 && calculateAverage()<=6.9){
            System.out.println("The student's average is " + calculateMedia() + " and his concept is C ");
        }
    }
    
    
}
