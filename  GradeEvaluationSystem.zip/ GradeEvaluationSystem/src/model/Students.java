/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author v3gc
 */
public class Students {
    private String studensName;
    private double studentsGrade1, studentsGrade2, studentsGrade3, gradeAverage;

    public String getStudensName() {
        return studensName;
    }

    public void setStudensName(String studensName) {
        this.studensName = studensName;
    }

    public double getStudentsGrade1() {
        return studentsGrade1;
    }

    public void setStudentsGrade1(double studentsGrade1) {
        this.studentsGrade1 = studentsGrade1;
    }

    public double getStudentsGrade2() {
        return studentsGrade2;
    }

    public void setStudentsGrade2(double studentsGrade2) {
        this.studentsGrade2 = studentsGrade2;
    }

    public double getStudentsGrade3() {
        return studentsGrade3;
    }

    public void setStudentsGrade3(double studentsGrade3) {
        this.studentsGrade3 = studentsGrade3;
    }

    public double getGradeAverage() {
        return gradeAverage;
    }

    public void setGradeAverage(double gradeAverage) {
        this.gradeAverage = gradeAverage;
    }
    
    
   
}
